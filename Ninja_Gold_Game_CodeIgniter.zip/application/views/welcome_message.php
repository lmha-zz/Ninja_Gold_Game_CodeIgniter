<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
<div id="container">

<?php
foreach ($users as $key => $array) {
	var_dump($array);
}
?>
</div>
</body>
</html>